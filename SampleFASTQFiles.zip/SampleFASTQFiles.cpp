/* 
    SampleFASTQFiles - Sample a FASTQ file 
    Copyright (C) 2012  Pelin Akan (pelin.akan@scilifelab.se)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU Affero General Public License as
    published by the Free Software Foundation, either version 3 of the
    License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of 
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU Affero General Public License for more details.                  

    For a copy of the GNU Affero General Public License
    see <http://www.gnu.org/licenses/>.
*/

#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <iostream>
#include <fstream>
#include <iomanip>
#include <time.h>
#include <cstring>
#include <string>
#include <time.h>
#include <vector>
#include <omp.h>
#include <sstream>
using namespace std;

static int print_usage()
{
  fprintf(stderr, "\n");
  fprintf(stderr, "Program: Sample FASTQ Files \n");
  fprintf(stderr, "Contact: Pelin Akan <pelin.akan@scilifelab.se>\n\n");
  fprintf(stderr, "Usage 1: SampleFASTQFiles inputfile -l [INT] \n");
  fprintf(stderr, "It will either prints an l number of reads from the FASTQ files (sampled over the whole file) OR \n");
  fprintf(stderr, "Usage 2: SampleFASTQFiles inputfile -p [INT] \n");
  fprintf(stderr, "It will prints p percentage of reads from the FASTQ files (sampled over the whole file) OR \n");
  fprintf(stderr, "-l the number of reads you wish to sample \n");
  fprintf(stderr, "-p the percentage of the reads you wish to sample (if 10%, enter 10) \n"); 
  return 0;
}

int main (int argc, char *argv[])
{
  //First argument name of the file
  //Second argument how many reads to sample 

  if(argc < 3){
	  print_usage();
	  return -1;    
  }
  else{
	ifstream fastq_in; // Input FASTQ file
	ofstream fastq_out; //Output FASTQ file
	string line;
	int i=0,j=0,k=0;
	double perc, noflines,nofslines,sfreq;
	long int nofreadstosample,samplingfreq=100;
       
//	for(i=0;i<argc;i++)
//	  cout << i << "  " << argv[i] << endl;
	string optind=argv[2];
	if(optind=="-p"){
	  perc=atof(argv[3]);
	  if(perc>100.0 || perc<=0){
	    cerr << "Enter a percentage between 0 to 100" << endl;
	    exit(1);
	  }
	  string command="wc -l ";
	  command.append(argv[1]);
	  command.append(" >tempcountlines");
	  cout << "Counting the lines in FASTQ file... " << endl;
	  system(command.c_str());
	  ifstream tempf("tempcountlines");
	  tempf >> noflines;
	  tempf.close();
	  noflines/=4;
	  nofslines=noflines*(perc/100.0);
	  sfreq=noflines/nofslines;
	  nofreadstosample=int(nofslines);
	  samplingfreq=int(sfreq); 
	}
	if(optind=="-l")
	   nofreadstosample=atoi(argv[3]);

	fastq_in.open(argv[1]);
	if (!fastq_in.is_open()) {
	  cerr << "Can't open input file " << argv[1] << endl;
	  exit(1);
	}

	strcat(argv[1],".sample");
	fastq_out.open(argv[1]);
	cout << "Number of Reads to Sample  " << nofreadstosample << endl;
	do{
		if(i%samplingfreq==0){
			for(j=0;j<4;j++){
			  getline(fastq_in,line);
			  fastq_out << line << endl;
			}
			++k;
			if(k%250000==0)
			  cout << k << "    Reads Sampled" << endl;
		}
		else{
			for(j=0;j<4;j++)
			  getline(fastq_in,line);
		}
		i+=4;
	}while(k<nofreadstosample);
	fastq_in.close();
	fastq_out.close();
}
 
  return 0;
}
